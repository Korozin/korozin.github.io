Void texture pack, originally from ver 1.8 on Java. Used an automatic texture converter created by PhoenixArc, but adapted to work for 1.8 packs by Korozin 
